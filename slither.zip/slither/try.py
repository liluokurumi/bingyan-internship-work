import pygame
import random
from pygame.locals import *
class BasePlane():
    def __init__(self,type,screen):
        self.type=type
        if self.type==HeroPlane:
            self.x = 150
            self.y = 400
            self.imageName = './planePro/hero.png'
            pass
        elif self.type==EnemyPlane:
            self.x=0
            self.y = 0
            self.imageName ='./planePro/enemy0.png'
            self.direction = 'right'
            pass
        self.image = pygame.image.load(self.imageName)
        self.bulletList = []
        self.needDelList = []
        self.screen = screen
    def display(self):
        self.screen.blit(self.image, (self.x, self.y))
        needDelList = []
        for item in self.bulletList:
            if item.judge():
                needDelList.append(item)
                pass
            else:
                pass
            pass
        for i in needDelList:
            self.bulletList.remove(i)
            pass
        for itemA in self.bulletList:
            itemA.display()
            itemA.move()




class HeroPlane(BasePlane):
    def MoveLeft(self):
        if self.x>0:
            self.x-=10
            pass
    def MoveRight(self):
        if self.x<310:
            self.x+=10
            pass
    def shoot(self):
        bulletA=bullet(self.x,self.y,self.screen)
        self.bulletList.append(bulletA)
    pass
def KeyControl(heroobj):
    eventList = pygame.event.get()
    for event in eventList:
        if event.type == QUIT:
            print('退出')
            exit()
            pass
        elif event.type == KEYDOWN:
            if event.key == K_a or event.key == K_LEFT:
                print('left')
                heroobj.MoveLeft()
                pass
            elif event.key == K_d or event.key == K_RIGHT:
                print('right')
                heroobj.MoveRight()
                pass
            elif event.key == K_SPACE:
                print('K_SPACE')
                heroobj.shoot()
def main():
    screen=pygame.display.set_mode((350,500))
    background=pygame.image.load('./planePro/background.png')
    pygame.display.set_caption('飞机大战')
    pygame.mixer.init()
    pygame.mixer.music.load('./planePro/background.mp3')
    pygame.mixer.music.set_volume(0.2)
    pygame.mixer.music.play(-1)
    hero=HeroPlane(HeroPlane,screen)
    enemy=EnemyPlane(EnemyPlane,screen)
    while True:
        screen.blit(background,(0,0))
        hero.display()
        enemy.display()
        enemy.move()
        enemy.shoot()
        KeyControl(hero)
        pygame.display.update()
    pass
class bullet():
    def __init__(self,x,y,screen):
        self.screen=screen
        self.x=x+13
        self.y=y-20
        self.imageName='./planePro/bullet.png'
        self.image=pygame.image.load(self.imageName)
        pass
    def display(self):
        self.screen.blit(self.image,(self.x,self.y))
        pass
    def move(self):
        self.y-=3
        pass
    def judge(self):
        if self.y<0:
            return True
        else:
            return False
class EnemyPlane(BasePlane):
    def shoot(self):
        num=random.randint(1,50)
        if num==3:
            bulletA = EnemyBullet(self.x, self.y, self.screen)
            self.bulletList.append(bulletA)
            pass
        pass
    def move(self):
        if self.direction=='right':
            self.x+=1
            pass
        else:
            self.x-=1
            pass
        if self.x>350:
            self.direction='left'
            pass
        elif self.x<0:
            self.direction='right'


class EnemyBullet():
    def __init__(self,x,y,screen):
        self.screen=screen
        self.x=x
        self.y=y
        self.imageName='./planePro/bullet1.png'
        self.image=pygame.image.load(self.imageName)
        pass
    def display(self):
        self.screen.blit(self.image,(self.x,self.y))
        pass
    def move(self):
        self.y+=1
        pass
    def judge(self):
        if self.y>450:
            return True
        else:
            return False
if __name__=='__main__':
   main()