num=4
listA=[1,2,3,4,5]
while num>0:
    print(listA[num-1])
    num-=1




