using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Egrow : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        int num1 = gameObject.GetComponent<length>().num2;
        print("work");
        GameObject FS = this.transform.parent.gameObject;
        print("work");
        GameObject FSB = FS.transform.Find("SBody").gameObject;
        print("work");
        string Fname = FS.name;
        print("work");
        string num7 = Fname.Substring(10, Fname.Length - 10);
        print("num7");
        int n1 = Convert.ToInt32(num7);
        print("work");
        for (int n = 1; n <= num1; n += 1)
        {
            string name1 = "SBody" + n;
            print("work");
            if (FSB.transform.Find(name1))
            {

            }
            else
            {
                print("work");
                GameObject PrefabsSBody = Resources.Load("ESBody") as GameObject;
                GameObject NSBody = Instantiate(PrefabsSBody, new Vector3(50 * n1, 0, 0), Quaternion.Euler(1, 1, 0));
                NSBody.transform.parent = FSB.transform;
                NSBody.name = "SBody" + n;
            }
        }
    }
    //private void OnTriggerEnter2D(Collider2D other)
    //{
        //print(other.gameObject.name);
        //gameObject.GetComponent<length>().Fpoint += 1;
        //GameObject.Destroy(other.gameObject);


    //}
}
