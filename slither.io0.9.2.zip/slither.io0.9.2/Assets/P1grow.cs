using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P1grow : MonoBehaviour
{
    public int Bcount;
    // Start is called before the first frame update
    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {
        int num1 = gameObject.GetComponent<length>().num2;
        GameObject FS = this.transform.parent.gameObject;
        GameObject FSB = FS.transform.Find("SBody").gameObject;
        Bcount = FSB.transform.childCount;
        if (Bcount <= num1)
        {
            for (int n = 1; n <= num1; n += 1)
            {

                string name1 = "SBody" + n;
                if (FSB.transform.Find(name1))
                {

                }
                else
                {
                    GameObject PrefabsSBody = Resources.Load("P1SBody") as GameObject;
                    GameObject NSBody = Instantiate(PrefabsSBody, null, true);
                    NSBody.transform.parent = FSB.transform;
                    NSBody.transform.position = new Vector3(-1, 0, 0);
                    NSBody.name = "SBody" + n;
                }
            }
        }
        else
        {
            int n3 = Bcount - num1;
            for (int n4 = 1; n4 <= n3; n4++)
            {
                GameObject DelSBody = FSB.transform.Find("SBody" + Bcount).gameObject;
                GameObject.Destroy(DelSBody);
                Bcount -= 1;
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Time.captureFramerate = 60;
        GameObject FatherO = other.gameObject.transform.parent.gameObject;
        if (FatherO.name == "foodcontrol")
        {
            print(other.gameObject.name);
            gameObject.GetComponent<length>().Point += 1;
            GameObject.Destroy(other.gameObject);
        }
        else
        {
            GameObject GFatherO = FatherO.gameObject.transform.parent.gameObject;
            if (GFatherO.name == "PlayerSnake1")
            {

            }
            else
            {
                GameObject.Destroy(this.transform.parent.gameObject);
            }
        }


    }







}