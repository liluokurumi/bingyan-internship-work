using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Egrow : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Time.captureFramerate = 60;
        int num1 = gameObject.GetComponent<length>().num2;
        GameObject FS = this.transform.parent.gameObject;
        GameObject FSB = FS.transform.Find("SBody").gameObject;
        string Fname = FS.name;
        string num7 = Fname.Substring(10, Fname.Length - 10);
        int n1 = Convert.ToInt32(num7);
        for (int n = 1; n <= num1; n += 1)
        {
            string name1 = "SBody" + n;;
            if (FSB.transform.Find(name1))
            {

            }
            else
            {
                GameObject PrefabsSBody = Resources.Load("ESBody") as GameObject;
                GameObject NSBody = Instantiate(PrefabsSBody, new Vector3(50 * n1, 0, 0), Quaternion.Euler(1, 1, 0));
                NSBody.transform.parent = FSB.transform;
                NSBody.name = "SBody" + n;
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        GameObject FatherO = other.gameObject.transform.parent.gameObject;
        if (FatherO.name == "foodcontrol")
        {
            print(other.gameObject.name);
            gameObject.GetComponent<length>().Fpoint += 1;
            GameObject.Destroy(other.gameObject);
        }
        else
        {
            GameObject GFatherO = FatherO.gameObject.transform.parent.gameObject;
            if (GFatherO.name == this.transform.parent.gameObject.name)
            {

            }
            else
            {
                GameObject.Destroy(this.transform.parent.gameObject);
            }


        }
    }
}
