using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnDestroy()
    {
        GameObject DSB = this.transform.Find("SBody").gameObject;
        Transform[] allChildren = DSB.GetComponentsInChildren<Transform>();
        foreach(Transform child in allChildren)
        {
            Vector3 PPosition = child.GetComponent<Transform>().position;
            for (int item = 1; item <= 5; item++)
            {
                GameObject Prefabsfood = Resources.Load("food") as GameObject;
                GameObject Nfood = Instantiate(Prefabsfood, null, true);
                GameObject SBody = GameObject.Find("foodcontrol");
                Nfood.transform.parent = SBody.transform;
                Nfood.GetComponent<Transform>().position = PPosition;
                Nfood.name = "food" + item;
            }
        }
    }
}
