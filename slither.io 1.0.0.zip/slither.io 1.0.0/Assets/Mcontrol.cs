using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mcontrol : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Time.captureFramerate = 60;
        transform.localScale = new Vector3(transform.localScale.x - Time.deltaTime*3, transform.localScale.y - Time.deltaTime*3, 0);

    }
}
