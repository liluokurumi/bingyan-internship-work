using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class length : MonoBehaviour
{
    public int num;
    public int Fpoint;
    public int num2;
    public double Point;
    // Start is called before the first frame update
    void Start()
    {
        Fpoint = 0;
        Point = num * 5 + Fpoint;



    }

    // Update is called once per frame
    void Update()
    {
        Time.captureFramerate = 60;
        num2 = (int)Point / 5;
        if (Input.GetButton("Fire1"))
        {
            Point -= 0.0417;
        }
        else
        {

        }




    }
}
