using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using UnityEngine;

public class Emovefinal : MonoBehaviour
{
    public float speed;
    public GameObject other;
    public Queue<Vector3> Hposition = new Queue<Vector3>();
    public int signnum;
    public GameObject coolest;
    public Vector2 AnglePosition;
    // Start is called before the first frame update
    void Start()
    {
        ;
        signnum = 0;
    }
    private void OnTriggerEnter2D(Collider2D coll)
    {
        if(coll.name == "map")
        {
            signnum = 4;
            print("����ǽ");
         }
        else
        {
            GameObject FatherO = coll.gameObject.transform.parent.gameObject;
            if (FatherO.name != "foodcontrol")
            {
                if (coll.name != "SBody1")
                {
                    if (FatherO.name == "SBody")
                    {
                        GameObject GFatherO = FatherO.transform.parent.gameObject;
                        if (GFatherO.name == this.transform.parent.gameObject.name)
                        {

                        }
                        else
                        {
                            signnum = 1;
                            print("Ҫ����·��");
                        }
                    }
                }
            }
            else if (coll.name == "SBody1")
            {
                GameObject GFatherO = FatherO.transform.parent.gameObject;
                if (GFatherO.name == this.transform.parent.gameObject.name)
                {

                }
                else
                {
                    signnum = 2;
                    print("attack");
                }
            }
            else
            {
                signnum = 3;
                print("eat");
            }
            coolest = coll.gameObject;
            print(coolest.name);
        }
        




    }
    void Update()
    {
        GameObject FSH = this.transform.parent.gameObject;
        other = FSH.transform.Find("SHead").gameObject;
        other.GetComponent<Transform>().position = gameObject.GetComponent<Transform>().position;
        Time.captureFramerate = 60;
        if (signnum == 1)
        {
            Vector2 SBodyPosition = coolest.GetComponent<Transform>().position;
            Vector2 SHeadPosition = gameObject.GetComponent<Transform>().position;
            AnglePosition = SHeadPosition - SBodyPosition;
            print("���½����");
        }
        else if (signnum == 2)
        {
            Vector2 SHeadPosition = gameObject.GetComponent<Transform>().position;
            Vector2 SBody1Position = gameObject.GetComponent<Transform>().position;
            AnglePosition = SBody1Position - SHeadPosition;
            print("����");
        }
        else if (signnum == 3)
        {
            if (coolest)
            {
                Vector2 FoodPosition = coolest.GetComponent<Transform>().position;
                Vector2 SHeadPosition = gameObject.GetComponent<Transform>().position;
                AnglePosition = FoodPosition - SHeadPosition;
            }
        }
        else if(signnum == 4)
        {
            Vector2 zeroP = new Vector2(0, 0);
            Vector2 SHeadPosition = gameObject.GetComponent<Transform>().position;
            AnglePosition = zeroP - SHeadPosition;
        }
        else
        {
            print("��ʼ�������·���");
            AnglePosition = new Vector2(5, 0);
        }
        transform.position += new Vector3(AnglePosition.normalized.x * Time.deltaTime * 7.5f, AnglePosition.normalized.y * Time.deltaTime * 7.5f, 0);
        Hposition.Enqueue(gameObject.GetComponent<Transform>().position);
        if (Hposition.Count == 1000)
        {
            Hposition.Dequeue();
        };
    }
}