using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using UnityEngine;

public class Emoveenenmy : MonoBehaviour
{
    public float speed;
    public GameObject other;
    public Queue<Vector3> Hposition = new Queue<Vector3>();
    public int signnum;
    public GameObject coolest;
    // Start is called before the first frame update
    void Start()
    {;
        signnum = 0;
    }
    private void OnTriggerEnter2D(Collider2D coll)
    {
        GameObject FatherO = coll.gameObject.transform.parent.gameObject;
        if(coll.name != "SBody1")
        {
            if(FatherO.name == "SBody")
            {
                GameObject GFatherO = FatherO.transform.parent.gameObject;
                if(GFatherO.name == this.transform.parent.gameObject.name)
                {

                }
                else
                {
                    signnum = 1;
                    print("Ҫ����·��");
                }
            }
        }
        else if(coll.name == "SBody1")
        {
            GameObject GFatherO = FatherO.transform.parent.gameObject;
            if(GFatherO.name == this.transform.parent.gameObject.name)
            {

            }
            else
            {
                signnum = 2;
                print("attack");
            }
        }
        else
        {
            signnum = 3;
            print("eat");
        }
        coolest = coll.gameObject;



        
    }
    void Update()
    {
        GameObject FSH = this.transform.parent.gameObject;
        other = FSH.transform.Find("SHead").gameObject;
        other.GetComponent<Transform>().position = gameObject.GetComponent<Transform>().position;
        Time.captureFramerate = 60;
        if (signnum == 1)
        {
            print("���½����");
        }
        else if(signnum == 2)
        {
            print("����");
        }
        else if(signnum == 3)
        {
            print("ǡ��");
        }
        else
        {
            print("��ʼ�������·���");
        }
        transform.position += new Vector3(Time.deltaTime * 5, 0, 0);
        Hposition.Enqueue(gameObject.GetComponent<Transform>().position);
        if (Hposition.Count == 1000)
        {
            Hposition.Dequeue();
        };
    }
}
