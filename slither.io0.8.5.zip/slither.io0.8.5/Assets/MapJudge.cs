using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapJudge : MonoBehaviour
{
    public GameObject other;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if ((gameObject.GetComponent<Transform>().position.x<-other.GetComponent<Transform>().localScale.x/2)|| (gameObject.GetComponent<Transform>().position.x > other.GetComponent<Transform>().localScale.x/2)|| (gameObject.GetComponent<Transform>().position.y < -other.GetComponent<Transform>().localScale.y/2)|| (gameObject.GetComponent<Transform>().position.y > other.GetComponent<Transform>().localScale.y / 2))
        {
            GameObject.Destroy(this.transform.parent.gameObject);
        }
    }
}
