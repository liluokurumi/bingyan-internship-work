using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class food1 : MonoBehaviour
{
    public GameObject other;
    // Start is called before the first frame update
    void Start()
    {
        int i = 10000;
        for (int n = 0; n <= i; n += 1)
        {
            GameObject Prefabsfood = Resources.Load("food") as GameObject;
            GameObject Nfood = Instantiate(Prefabsfood, null, true);
            GameObject SBody = GameObject.Find("foodcontrol");
            Nfood.transform.parent = SBody.transform;
            Nfood.GetComponent<Transform>().position = new Vector3(Random.Range(-500, 500), Random.Range(-500, 500), 0);

            Nfood.name = "food" + n;
        }
    }

    // Update is called once per frame
    void Update()
    {
        double SC = other.GetComponent<Transform>().localScale.x / 1000;
        int fnum = transform.childCount;
        int count = 4000 * (int)SC;
        print("work successfully");
        if (fnum <= 6000 * SC)
        {
            print("work successfully");
            for (int n = 1; n <= count; n++)
            {
                GameObject Prefabsfood = Resources.Load("food") as GameObject;
                GameObject Nfood = Instantiate(Prefabsfood, null, true);
                GameObject SBody = GameObject.Find("foodcontrol");
                Nfood.transform.parent = SBody.transform;
                Nfood.GetComponent<Transform>().position = new Vector3(Random.Range(-other.GetComponent<Transform>().localScale.x / 2, other.GetComponent<Transform>().localScale.x / 2), Random.Range(-other.GetComponent<Transform>().localScale.y / 2, other.GetComponent<Transform>().localScale.y / 2), 0);
            }

        }

    }
}
